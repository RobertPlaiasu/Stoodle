<?php


$array_judet=array("Alba","Arad ","Arges","Bacau","Bihor","Bistrita-Nasaud","Botosani","Braila","Brasov","Buzau","Calarasi","Caras-Severin","Cluj","Constanta","Covasna","Dambovita",
"Dolj","Galati","Giurgiu","Gorj","Harghita","Hunedoara","Ialomita","Iasi","Ilfov","Maramures","Mehedinti","Mures","Neamt","Olt","Prahova","Salaj","Satu-Mare","Sibiu","Suceava","Teleorman",
"Timis","Tulcea","Valcea","Vaslui","Vrancea");

$array_materie=array("Limba si literatura romana","Engleza","Franceza","Germana","Spaniola","Matematica","Fizica","Educatie fizica","Religie","Informatica","TIC","Educatie civica","Desen","Muzica",
"Biologie","Chimie","Istorie","Geografie","Economie","ATP","Latina","Psihologie","Sociologie");
$array_materie1=array("Niciuna din cele de mai jos","Limba si literatura romana","Engleza","Franceza","Germana","Spaniola","Matematica","Fizica","Educatie fizica","Religie","Informatica","TIC","Educatie civica","Desen","Muzica",
"Biologie","Chimie","Istorie","Geografie","Economie","ATP","Latina","Psihologie","Sociologie");

$array_carti=array("Culinare","Arte,tehnica","Enciclopedii","Biografii,memorii","Lingvistica","Limbi straine","Teatru","Poezie/Literatura","Fictine","Atlase,ghiduri turistice","Istorie","Religie",
"Filozofie","Psihologie","Stiinte sociale,politica","Marketing si comunicare","Business si economie","Drept","Medicina","Stiinte exacte","Natura si mediu","Tehnica si tehnologie",
"Computere si internet","Dezvoltare personala","Lifestyle,sport");
$array_pasiune=array("Medicina","Matematica","Agricultura","Ecologie","Programare/Calculatoare","Literatura","Muzica","Desen","Arhitectura","Astronomie","Fizica","Sport","Religie","Economie",
"Business","Politica","Limbi straine","Filozofie","Drept","Biologie","Geografie","Geologie","Istorie","Jurnalism","Psihologie","Design","Constructii","Serviciul militar","Actorie","Regie","Editare video/sunet",
"Chimie","Animale","Limba romana","Serviciul in cadrul politiei","Electronica","Inginerie electrica","Cibernetica","Inginerie Aerospatila");

$array_profil=array("Teologic","Mate-info","Filologie","Stiinte ale naturii","Sportiv","Tehnologic","Arhitectura","Actorie","Stiinte-sociale");
 ?>
