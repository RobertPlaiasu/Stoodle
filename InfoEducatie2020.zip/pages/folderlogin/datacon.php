<?php
 $server="r43949el_Stoodle";
 $dbuser="r43949el_admin";
 $dbpass="r43949el_";
 $dbname="Stoodle";

 $connection=mysqli_connect($server,$dbuser,$dbpass,$dbname);
 if (!$connection) {
   die("Connection failed:  ".mysqli_connect_error());
 }
