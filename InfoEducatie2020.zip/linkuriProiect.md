# Linkuri folosite pentru crearea acestui proiect

1. Trello: https://trello.com/b/tCwrQPeG/stoodle
>Am decis să folosim trello pentru a ne putea urmării progresul și pentur o viziune clară asupra ce urmează să facem
